<?php
require 'vendor/autoload.php'; // Load pdf-lib library

use PDFLib\PDFDocument;
use PDFLib\rgb;

$pdfDoc = PDFDocument::create();
$frontPage = $pdfDoc->addPage([500, 500]);
$logoImage = $pdfDoc->embedPng(file_get_contents('Logo.png')); // Use PNG logo

$frontPage->drawRectangle([
  'x' => 0,
  'y' => 0,
  'width' => 500,
  'height' => 500,
  'color' => rgb(255, 255, 0),
  'fill' => rgb(255, 255, 0),
]);

$frontPage->drawImage($logoImage, [
  'x' => 0,
  'y' => 0,
  'width' => 500,
  'height' => 500,
]);

$sections = file_get_contents('your-text-file.txt');
$sections = explode('#section-', $sections);
array_shift($sections);

foreach ($sections as $section) {
  list($id, $content) = explode("\n", $section);
  $page = $pdfDoc->addPage([500, 500]);

  $page->drawText([
    'text' => $content,
    'x' => 50,
    'y' => 500 - 50,
    'size' => 12,
    'color' => rgb(0, 0, 0),
  ]);
}

$pdfBytes = $pdfDoc->save();
file_put_contents('output.pdf', $pdfBytes);

echo 'PDF generated successfully.';
?>
