const fs = require('fs');
const { PDFDocument, rgb } = require('pdf-lib');

async function generatePDF() {
  const pdfDoc = await PDFDocument.create();
  const text = await fs.promises.readFile('input.txt', 'utf8');
  const sections = text.split('#section-');
  sections.shift(); // Remove the first empty entry

  const pageWidth = 500;
  const pageHeight = 700; // Increase the page height to accommodate text

  // Add page for logo with yellow background
  const logoPage = pdfDoc.addPage([pageWidth, pageHeight]);
  logoPage.drawRectangle({
    x: 0,
    y: 0,
    width: pageWidth,
    height: pageHeight,
    color: rgb(1, 1, 0), // Yellow background color
  });

  // Draw logo image
  const logoImage = await pdfDoc.embedPng(fs.readFileSync('Logo.png'));
  logoPage.drawImage(logoImage, {
    x: pageWidth * 0.25, // Adjust positioning as needed
    y: pageHeight * 0.5, // Adjust positioning as needed
    width: pageWidth * 0.5, // Adjust size as needed
    height: pageHeight * 0.5, // Adjust size as needed
  });

  sections.forEach(section => {
    const [id, ...contentLines] = section.split('\n');
    const fieldId = id; // No need for mapping since we removed bold headers

    const page = pdfDoc.addPage([pageWidth, pageHeight]);

    // Draw section header
    page.drawText(id, {
      x: 50,
      y: page.getHeight() - 50,
      size: 14, // Decrease font size
      color: rgb(0, 0, 0),
    });

    // Draw section content with line breaks
    const content = contentLines.join('\n');
    const contentHeight = page.drawText(content, {
      x: 50,
      y: page.getHeight() - 80,
      size: 14, // Decrease font size
      color: rgb(0, 0, 0),
      maxWidth: pageWidth - 100, // Adjust maxWidth to fit within the margins
      maxHeight: page.getHeight() - 140, // Adjust maxHeight to fit within the margins
    });

    // If the content exceeds the available space, continue on the next page
    if (contentHeight <= 0) {
      pdfDoc.removePage(page);
    }
  });

  const pdfBytes = await pdfDoc.save();

  await fs.promises.writeFile('EazyPolicy.pdf', pdfBytes);
  console.log('PDF generated successfully.');
}

generatePDF().catch(err => {
  console.error('Error generating PDF:', err);
});
