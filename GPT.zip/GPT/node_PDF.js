const fs = require('fs');

// Read the contents of the text file
fs.readFile('your-text-file.txt', 'utf8', (err, text) => {
  if (err) {
    console.error('Error reading the text file:', err);
    return;
  }

  const sections = text.split('#section-');
  sections.shift(); // Remove the first empty entry

  const idToFieldMap = {
    'collection': 'section-collection',
    'usage': 'section-usage',
    'storage': 'section-storage',
    'sharing': 'section-sharing',
    'rights': 'section-rights'
  };

  sections.forEach(section => {
    const [id, content] = section.split('\n');
    const fieldId = idToFieldMap[id];
    console.log(`${fieldId}: ${content}`); // Print the mapping for testing purposes
    // In a real scenario, you would set the value of the form field here
  });
});
