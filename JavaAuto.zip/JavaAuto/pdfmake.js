const PDFDocument = require('pdfkit');
const fs = require('fs');

// Create a new PDF document
const doc = new PDFDocument();
const outputStream = fs.createWriteStream('output.pdf');
doc.pipe(outputStream);

// Define text fields with IDs and positions
const textFields = [
  { id: 'Information Collection', x: 50, y: 100, width: 400, height: 30 },
  { id: 'Information Usage', x: 50, y: 150, width: 400, height: 30 },
  { id: 'Information Usage', x: 50, y: 200, width: 400, height: 30},
  { id: 'Information Sharing', x: 50, y: 250, width: 400, height: 30 },
  { id: 'User Rights', x: 50, y: 300, width: 400, height: 30 }
];

// Add text fields to the PDF
textFields.forEach(field => {
  doc.text(` ${field.id}`, field.x, field.y - 15);
  doc.rect(field.x, field.y, field.width, field.height).stroke();
});

// Add fillable text fields to the PDF
textFields.forEach(field => {
    const annot = doc.annot({ subtype: 'Widget', rect: [field.x, field.y, field.width, field.height] });
    const formField = doc.formField(field.id, 'text', annot);
    formField.defaultValue('');
  });
  

// Finalize and close the PDF
doc.end();
